#include "Character.h"
#include "Item.h"
#include "Creature.h"
#include "Battle.h"
#include "Wisdom.h"
#include "Instantiate.h"
#include <string>
#include <vector>
#include <iostream>
class Tests{
	void tests()
	{
		/*____________________TESTS____________________*/

		/******************INSTANTIATE********************/
		Instantiate gameDBs = Instantiate();
		//test makeInventory method
		gameDBs.makeItems();
		gameDBs.makeCreatures();
		gameDBs.makeWisdoms();

		/******************CHARACTER********************/
		std::cout << "TESTING CHARACTER CLASS" << endl;
		//Create an instance of the Character Class
		std::vector<Item> inventory;
		Character test_character = Character("Joanna", 100, 50, inventory);

		//Make sure setters and getters function correctly
		test_character.setHealth(75);
		int test_health = test_character.getHealth();
		std::cout << "Health is: " << test_health << endl;

		test_character.setStrength(25);
		int test_strength = test_character.getStrength();
		std::cout << "Strength is: " << test_strength << endl;

		//Make sure increase and decrease methods function correctly
		test_character.increaseHealth(25);
		test_health = test_character.getHealth();
		std::cout << "Health after increase is: " << test_health << endl;

		test_character.decreaseHealth(25);
		test_health = test_character.getHealth();
		std::cout << "Health after decrease is: " << test_health << endl;

		//Make sure decrease health triggers if statement
		//test_character.decreaseHealth(75); --this works

		//Make sure inventory methods function correctly
		Item test_item = gameDBs.items.at(0);
		Item test_item2 = gameDBs.items.at(1);
		test_character.addItem(test_item);
		test_character.addItem(test_item2);
		vector<Item> test_inven = test_character.getInventory();
		for (Item i : test_inven) {
			std::cout << "Inventory Item: " << i.getName() << endl;
		}

		test_inven = test_character.getInventory();
		for (Item i : test_inven) {
			std::cout << "Inventory Item: " << i.getName() << endl;
		}

		//check that remove method returns false if not found
		Item test_item_3 = Item("Shield", "strength", 30);
		bool test = test_character.removeItem(test_item_3);
		std::cout << test << endl;
		test_inven = test_character.getInventory();
		for (Item i : test_inven) {
			std::cout << "Inventory Item: " << i.getName() << endl;
		}


		/******************ITEM********************/
		std::cout << "TESTING ITEM CLASS" << endl;
		//Create an instances of the Item Class
		Item test_item_h = gameDBs.items.at(1);
		Item test_item_s = gameDBs.items.at(0);

		//Make sure setters and getters function correctly
		test_health = test_item_h.getHealth_Strength();
		std::cout << "Health is: " << test_health << endl;
		test_item_h.setHealth_Strength(75);
		std::cout << "Health is: " << test_item_h.getHealth_Strength() << endl;

		test_strength = test_item_s.getHealth_Strength();
		std::cout << "Strength is: " << test_strength << endl;
		test_item_s.setHealth_Strength(25);
		std::cout << "Strength is: " << test_item_s.getHealth_Strength() << endl;

		/******************CREATURE********************/
		std::cout << "TESTING CREATURE CLASS" << endl;
		//Create an instances of the Creatures Class
		Creature test_creature = gameDBs.creatures.at(0);

		//Make sure setters and getters function correctly
		std::cout << "Health is: " << test_creature.getHealth() << endl;
		test_creature.setHealth(50);
		std::cout << "Health is: " << test_creature.getHealth() << endl;

		std::cout << "Strength is: " << test_creature.getStrength() << endl;
		test_creature.setStrength(25);
		std::cout << "Strength is: " << test_creature.getStrength() << endl;

		//Make sure decrease methods function correctly
		test_creature.decreaseHealth(25);
		std::cout << "Health after decrease is: " << test_creature.getHealth() << endl;

	
		//Make sure decrease health triggers if statement
		test_creature.decreaseHealth(25);

		/******************BATTLE********************/
		//Create an instances of the Battle Class
		Creature* test_creature_p;
		test_creature_p = &test_creature;
		Character* test_character_p;
		test_character_p = &test_character;
		Battle test_battle = Battle(test_creature_p, test_character_p);

		//test meetCreature method
		test_battle.meetCreature();

		/******************WISDOM********************/
		//Create an instances of the Wisdom Class
		Wisdom test_wisdom = Wisdom(gameDBs.wisdomQuestions, gameDBs.wisdomAnswers);

		//test getRiddle method
		string riddle = test_wisdom.getRiddle(0);
		std::cout << "This is the riddle: " << riddle << endl;

		//test getAnswer method
		string answer = test_wisdom.getAnswer(0);
		std::cout << "This is the answer: " << answer << endl;

	}
};
